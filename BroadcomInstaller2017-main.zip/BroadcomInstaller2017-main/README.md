# BroadcomInstaller2021	
Automated Shell Script Install WiFi  Driver ( Broadcom ) for Kali Linux 2021 

#Broadcom Wifi Driver (802.11n) Broadcom 802.11n Network Adapter is a software program developed by Broadcom.  
The software is designed to connect to the Internet and adds a Windows Firewall exception in order to do so without being interfered with.

Download Broadcom Installer :   
https://github.com/TadakaSuryaTeja/BroadcomInstaller2021.git   

usage :   
cd Desktop  git clone https://github.com/TadakaSuryaTeja/BroadcomInstaller2021.git  
cd BroadcomInstaller2021 
chmod +x ./Broadcom.sh  
./Broadcom.sh

1) Install Wifi Driver
2) Show Commands
3) Quit
Please enter your choice: 

Note: Once installation is done it will restart your system


credits: Made By SSTec Tutorials
